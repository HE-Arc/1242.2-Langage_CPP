#pragma once

#include "Wizard.h"

namespace He_Arc::RPG
{

    class Necromancer : public Wizard
    {
    public:
        Necromancer(int _strength = 10, int _agility = 5, int _intelligence = 1, double _hp = 20, std::string _name = "no_name_necromancer", int _mana = 10) : Wizard(_strength, _agility, _intelligence, _hp, _name, _mana){};

        virtual ~Necromancer() override = default;

        /**
         * @brief Rising undeads is, by far, the most noble act a necromancer can do.
         */
        void riseUndeads();

    protected:
    private:
    };
} // namespace He_Arc::RPG