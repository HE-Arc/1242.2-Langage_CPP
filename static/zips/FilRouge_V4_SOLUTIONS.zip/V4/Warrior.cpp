#include "Warrior.h"
#include <iostream>

namespace He_Arc::RPG
{

    void Warrior::interact(const Hero &otherHero)
    {
        std::cout << "I will fight you! @" << otherHero.getName() << std::endl;
    }
} // namespace He_Arc::RPG