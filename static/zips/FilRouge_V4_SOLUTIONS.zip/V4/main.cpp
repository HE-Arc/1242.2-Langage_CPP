#include <iostream>
#include <list>
#include <algorithm>
#include <vector>

#include "Hero.h"
#include "Warrior.h"
#include "Wizard.h"
#include "Necromancer.h"

#include "Sword.h"


using namespace std;
using namespace He_Arc::RPG;

int main()
{
    // Héritage
    Warrior gimli = {10, 5, 1, 20, "Gimli"};
    Wizard gandalf = {2, 2, 10, 10, "Gandalf", 10};
    Necromancer sauron = {20, 20, 10, 999.9, "Sauron", 50};

    gimli.show();
    cout << endl;
    gandalf.show();
    cout << endl;
    sauron.show();
    cout << endl;

    gimli.interact(gandalf);
    gandalf.interact(sauron);
    sauron.interact(gimli);

    sauron.castSpell(gandalf);
    sauron.riseUndeads();

    sauron.show();
    cout << endl;

    //V4 Polymorphisme with std::list
    auto pHero1 = new Warrior(2, 2, 1, 10, "Twoflower");
    auto pHero2 = new Warrior(4, 12, 10, 10, "Weasel");
    auto pHero3 = new Wizard(2, 2, 10, 10, "Rincewind", 3);
    auto pHero4 = new Necromancer(1, 1, 1, 10, "G.A. Romero ", 50);
    auto pHero5 = new Warrior(10, 7, 3, 20, "Bravd ");

    std::list<Hero *> myParty = {pHero1, pHero2, pHero3, pHero4, pHero5};

    for (const auto &hero : myParty)
    {
        hero->show();
    }

    // giving back the memory
    for (auto &hero : myParty)
    {
        delete hero;
        hero = nullptr;
    }

    // Advanced: std::for_each + lambda expression + utility Template method

    // std::for_each (myParty.begin(), myParty.end(), [](const auto & hero)
    //                                                    {
    //                                                    hero->show();
    //                                                    });

    // giving back the memory
    // std::for_each (myParty.begin(), myParty.end(), [](auto & hero)
    //                                                    {
    //                                                    Utility::deletePtr(hero);
    //                                                    });

    return 0;
}
