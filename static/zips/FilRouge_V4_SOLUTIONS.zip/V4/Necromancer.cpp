#include "Necromancer.h"

#include <iostream>

namespace He_Arc::RPG
{

    void Necromancer::riseUndeads()
    {
        if (mana > 2)
        {
            std::cout << "Creating undead... work in progress" << std::endl;
            mana -= 2;
        }

        else
        {
            std::cout << "Not enough mana!!" << std::endl;
        }
    }
} // namespace He_Arc::RPG