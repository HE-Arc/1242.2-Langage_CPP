#include <iostream>

#include "circle.h"
#include "rectangle.h"
#include "triangle.h"

using namespace std;

int main()
{
    Figure *myShapes[3];

    myShapes[0] = new Circle(Point(1.1, 5.3), 5.0);
    myShapes[1] = new Triangle(Point(2, 2), Point(10, 3), Point(-1, -1));
    myShapes[2] = new Rectangle(Point(4, 2), 4.0, 10.0);

    for (auto shape : myShapes)
        shape->show();

    cout << "All the shapes are translated:" << endl;
    for (auto shape : myShapes)
        shape->translate(Point(-1.5, -1.5));

    for (auto shape : myShapes)
        shape->show();

    for (auto shape : myShapes)
    {
        delete shape;
        shape = nullptr;
        cout << shape;
    }

    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
