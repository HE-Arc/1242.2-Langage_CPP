#include "triangle.h"

#include <iostream>

using namespace std;

void Triangle::show() const
{
    cout << "\nTriangle: ";
    Figure::show();
    pos2.show();
    pos3.show();
    cout << endl;
}

void Triangle::translate(const Point& shift)
{
    Figure::translate(shift);
    pos2.translate(shift);
    pos3.translate(shift);
}
