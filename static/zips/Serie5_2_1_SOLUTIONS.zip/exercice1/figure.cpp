#include "figure.h"
#include <iostream>

using namespace std;

void Figure::show() const
{
    pos.show();
}

void Figure::translate(const Point &shift)
{
    pos.translate(shift);
}
