#include <iostream>

#include "circle.h"
#include "rectangle.h"
#include "triangle.h"

using namespace std;

int main()
{


   Figure *myShapes[3];

    myShapes[0] = new Circle(Point(1.1, 5.3), 5.0);
    myShapes[1] = new Triangle(Point(2, 2), Point(10, 3), Point(-1, -1));
    myShapes[2] = new Rectangle(Point(4, 2), 4.0, 10.0);

    Figure *myShapesCopy1[3];

    for (int i=0;i<3;i++)
    {
        Circle* ptrCircle = dynamic_cast<Circle*> (myShapes[i]);
        if (ptrCircle != nullptr)
        {
            myShapesCopy1[i] = new Circle(*ptrCircle);
        }

        Triangle* ptrTriangle = dynamic_cast<Triangle*> (myShapes[i]);
        if (ptrTriangle != nullptr)
        {
            myShapesCopy1[i] = new Triangle(*ptrTriangle);
        }

        Rectangle* ptrRectangle = dynamic_cast<Rectangle*> (myShapes[i]);
        if (ptrRectangle != nullptr)
        {
            myShapesCopy1[i] = new Rectangle(*ptrRectangle);
        }
    }

    for (auto shape : myShapes)
    {
        delete shape;
        shape=nullptr;
    }

    cout << endl << "------- List of copied shapes ------" << endl;
    for (auto shape : myShapesCopy1)
        shape->show();


    for (auto shape : myShapesCopy1)
    {
        delete shape;
        shape=nullptr;
    }


    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
