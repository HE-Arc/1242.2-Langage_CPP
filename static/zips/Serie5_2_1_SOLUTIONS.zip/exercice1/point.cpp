#include "point.h"
#include <iostream>
using namespace std;

// initilalizing of the static variable
int Point::counter=0;

Point::Point(double _x, double _y, string _name): x(_x), y(_y), name(_name)
{
    counter++;
    cout << '[' << "Point::Constr std:" << counter << ']';
}

Point::Point(const Point &other)
{
    x = other.x;
    y = other.y;
    name = other.name;

    counter++;
    cout << '[' << "Point:: Constr cop:" << counter << ']';
}

Point::~Point()
{
    cout << '[' << "Point Destr:" << counter << ']';
    counter--;
}

void Point::show() const
{
    cout << endl << name << " : (" << x << ", " << y << ')';
}

void Point::translate(double _x, double _y)
{
    x+=_x;
    y+=_y;
}

void Point::translate(const Point &other)
{
    // call other translate signature
    this->translate(other.x, other.y);
}

