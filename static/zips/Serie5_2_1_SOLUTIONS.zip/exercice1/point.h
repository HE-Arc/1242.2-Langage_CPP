/**
    * @brief Serie 4.1, exercise 1
    *
    * @author HE-ARC, MSA, 2021
    * @version 1.0
  */

#pragma once

#include <string>

/**
 * @brief Class Point
*/
class Point
{
public:
  /**
  * @brief Parametrized constructor 
  */
  Point(double x = 0., double y = 0., std::string name = "Point");

  /**
  * @brief Copy constructor
  */
  Point(const Point &other);

  /**
  * @brief Destructor
  */
  ~Point();

  /**
  * @brief Display coordinates
 */
  void show() const;

  /**
  * @brief Get x coordinate
  */
  double getX() const {return x;}

  /**
  * @brief Get y coordinate
  */
  double getY() const {return y;}

  /**
  * @brief Get y coordinate
  */
  bool operator==(const Point& p)
  {
    return x==p.x && y==p.y;
  }

  /**
  * @brief translate point
  * @param dx delta x 
  * @param dy delta y
  */
  void translate(double dx, double dy);
  
  /**
  * @brief translate point
  * @param pt new position
  */
  void translate(const Point &other);

private:
  double x = 0.;    /**< x coordinate */
  double y = 0.;    /**< y coordinate */
  std::string name; /**< name of the point*/

public:
  static int counter; /**< static instances counter*/
};