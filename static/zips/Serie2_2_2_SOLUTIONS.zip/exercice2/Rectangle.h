#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "point.h"
class Rectangle
{
public:
  Rectangle(double = 0, double = 0, double = 0, double = 0);

  Rectangle(const Point &, const Point &);
  //Rectangle(Point, Point);  // this constructor would require the construction of two extra points (ineffective)

  bool contains(const Point &) const;
  double getPerimeter() const;
  void show() const;
  void translate(double, double);

private:
  Point cornerUL, cornerBR;
};

#endif // RECTANGLE_H
