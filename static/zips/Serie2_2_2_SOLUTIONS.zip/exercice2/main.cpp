/**
 *  Serie 02-2 : Premières classes

    Exercice 2 : classe Rectangle

    Buts:
            - Le constructeur avec des points passés par REFERENCE CONST
            - constructeur avec liste d'initialisation
            - Accès aux membres d'une autre classe avec friend ou des getter
            - Comprendre la copie des composants par le constructeur

    Note: les constructeurs des deux classes ont été rendus "bavards" par l'ajout de cout pour aider à comprendre
*/

#include <iostream>
#include "Point.h"
#include "Rectangle.h"

using namespace std;

int main()
{
    cout << "***POINTS CONSTRUCTION***" << endl;
    Point pt1('A', 5., 5.), pt2('B', 10., 12.), ptX('X', 7., 8.);
    cout << "***R CONSTRUCTION***" << endl;
    Rectangle R(pt1, pt2); // 2 calls to the Point copy constructor
    cout << "***R2 CONSTRUCTION***" << endl;
    Rectangle R2(1, 2, 3, 4);

    cout << "---------------" << endl;
    R.show();
    cout << "Perimetre : " << R.getPerimeter() << endl; // 24
    cout << "is ptX ";

    ptX.show();
    cout << " contained in the area of rectangle R ? " << boolalpha << R.contains(ptX) << endl;
    pt1.translate(3, 5);
    R.show(); // R is unchanged, as can be seen upon execution, copy points were built for R

    cout << "***COPY CONSTRUCTION***" << endl;
    Rectangle anotherRectangle(R); // COPY CONSTRUCTOR is working (automatic synthesis by the compiler)
    R.translate(-10., -15.);
    cout << "R after (-10.,-15.) translate :\n";
    R.show(); // R is unchanged, as can be seen upon execution, copy points were built for R
    cout << "anotherRectangle.show() :\n";
    anotherRectangle.show();

    cout << "\n\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
