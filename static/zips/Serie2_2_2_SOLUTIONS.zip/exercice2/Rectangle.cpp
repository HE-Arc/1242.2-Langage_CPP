#include "rectangle.h"
#include <iostream>
using namespace std;

/**
 * @brief constructeur standard avec 2 Point en paramètre,
 * @param p1 et p2 sont les points qui délimiteront le rectangle
          Note: si la classe Point n'a pas de constructeur par défaut, il est
          indispensable d'initialiser les membres points dans la liste d'initialisation
 * */

Rectangle::Rectangle(const Point &p1, const Point &p2) : cornerUL(p1), cornerBR(p2)
//Rectangle::Rectangle(Point p1, Point p2) : cornerUL(p1), cornerBR(p2)
{
    cout << "[ctor] Rectangle(const Point&, const Point&)" << endl;
}

/**
 *  Constructeur standard avec une liste d'initialisation
 * @param {x1,y1} --> ULcorner  {x2,y2} --> BRcorner  conditions :x1<x2 et y1<y2
*/
Rectangle::Rectangle(double x1, double y1, double x2, double y2) : cornerUL(x1, y1), cornerBR(x2, y2)
{
    cout << "[ctor]Rectangle(double x1, double y1, double x2, double y2)" << endl;
}

bool Rectangle::contains(const Point &p) const
{
    return (p.x >= cornerUL.x && p.x <= cornerBR.x && p.y >= cornerUL.y && p.y <= cornerBR.y);
}

/**
 *  @brief computes and return the perimeter of the rectangle
 *  @return the perimeter spanned by the UL (upper left) and BR (bottom right) corners
 */
double Rectangle::getPerimeter() const
{
    double height = cornerBR.y - cornerUL.y;
    double width = cornerBR.x - cornerUL.x;
    return 2 * (width + height);
}

/**
 * @brief shows the UL and BR corner points (using the Point::show() method twice)
 * */
void Rectangle::show() const
{
    cout << "[";
    cornerUL.show();
    cout << "  -  ";
    cornerBR.show();
    cout << "]  Perimeter :" << getPerimeter() << endl;
}

/**
 *  @brief will add a dx and dy value to the coordinates of both corners resulting in the
 *         Rectangle's translation
 *  @param dx: vertical translation, dy: horizontal translation
 *
 */
void Rectangle::translate(double dx, double dy)
{
    cornerUL.x += dx;
    cornerBR.x += dx;
    cornerUL.y += dy;
    cornerBR.y += dy;
}
