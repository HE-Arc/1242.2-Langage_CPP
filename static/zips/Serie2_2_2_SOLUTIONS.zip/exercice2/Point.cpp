#include "point.h"
#include <iostream>
using namespace std;

// initialisation de la variable count
int Point::counter = 0;

Point::Point(char c, double _x, double _y) : x(_x), y(_y), label(c)
{
    cout << "[ctor] Point(char c, double _x, double _y)" << endl;
    counter++;
}

Point::Point(const Point &other)
{
    x = other.x;
    y = other.y;
    label = other.label;

    cout << "[ctor] Point(const Point &other)" << endl;
    counter++;
}

void Point::show() const
{
    cout << label << " : (" << x << ',' << y << ')';
}

void Point::translate(double _x, double _y)
{
    x += _x;
    y += _y;
}
