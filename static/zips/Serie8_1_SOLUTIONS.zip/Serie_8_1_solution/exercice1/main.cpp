/**
*   Test code for the exception in functions
*
* @author HE-ARC, FRT
* @version 1.0
* @date 04.2021
*
*/
#include <iostream>
#include <cstdlib>
#include "myexception.hpp"

using namespace std;

void isPositive(int value);
void isOdd(int value);
void isLessThan(int value, int maxValue);
void isGreaterThan(int value, int minValue);

int main()
{
    int minValue=10;
    int maxValue=100;
    try
    {
        int value;
        cout<<"Enter a positive and odd value [" << minValue << ", " << maxValue << "] : ";
        cin >> value;
        isPositive(value);
        isOdd(value);
        isLessThan(value, maxValue);
        isGreaterThan(value, minValue);
        cout<<"Correct value !\n";  // pas d’exception lancée
    }
    catch(int val)
    {
        cout<<"Incorrect value ! ->  "  << val << endl;
    }
    catch(const char* str)
    {
        cout<<"Incorrect value ! ->  "  << str << endl;
    }
    catch(const MyException & err)
    {
        cout<<"Incorrect value ! ->  "  << err.what() << endl;
    }
    catch(...)
    {
        cout<<" Unknown error !\n";
    }
    cout << endl;
    system("pause");
    return 0;
}

void isPositive(int value)
{
    if( value < 0 )
    {
        throw  value;
    }
    cout << "- OK: It's a positive value" << endl;
}

void isOdd(int value)
{
    if( value % 2 == 0 )
    {
        throw  "The value is even";
    }
    cout << "- OK: It's an odd value" << endl;
}

void isLessThan(int value, int maxValue)
{
    if ( value > maxValue )
    {
        throw MyException("The value is too large");
    }
    cout << "- OK: It's a value less than " << maxValue  << endl;
}

void isGreaterThan(int value, int minValue)
{
    if( value < minValue )
    {
        throw MyException("The value is too small");
    }
    cout << "- OK: It's a value greater than " << minValue << endl;
}
