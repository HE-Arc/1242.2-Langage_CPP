#pragma once
/**
*   Definition of a class "MyException" inheriting from the class "exception"
*
* @author HE-ARC, FRT
* @version 1.0
* @date 04.2021
*
*/
#include <exception>
#include <string>


class MyException: public std::exception
{
private:

    std::string errorMessage = "Undefined error!";

public:

    /**
     * @brief Default compilator constructor 
     */
    MyException() noexcept = default;

    /**
     * @brief Parametrized constructor that initialise the errormessage
     * @param msg of type string
     */    
    MyException(std::string msg) noexcept;

    /**
     * @brief Default compilator destructor
     */
    virtual ~MyException() = default;

     /**
     * @brief Overrided method that shows the errorMessage.
     */
    const char* what() const noexcept override;

};

