/**
*   Implementation of a class "MyException" inheriting from the class "exception"
*
* @author HE-ARC, FRT
* @version 1.0
* @date 04.2021
*
*/

#include "myexception.hpp"
#include <exception>
#include <string>


MyException::MyException(std::string msg) noexcept
{
    errorMessage = msg;
}

const char* MyException::what() const noexcept
{
    return errorMessage.c_str();   // convert "string" to "char *
}