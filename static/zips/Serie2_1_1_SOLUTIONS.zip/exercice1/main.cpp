/**
 *  Serie 02.1 : Classes et Objets
 *  Exercise 1: Management of a bank account
*
*
* @author  FRT
* @date    22.02.2018
* @version 0.1
*/

#include <iostream>
#include <iomanip>
#include "BankAccount.h" // not used yet....

using namespace std;

class BankAccount
{
public:
    void init()
    {
        amount = 0;
    }

    void withdraw(float value)
    {
        if (value > 0 && amount > value)
            amount -= value;
    }

    void deposit(float value)
    {
        if (value > 0)
            amount += value;
    }

    void show()
    {
        cout << "The amount on your bank account is : "  << fixed << setprecision(2) << amount << endl;
    }

private:
    float amount;
};

int main()
{
    BankAccount myBankAccount;

    myBankAccount.show();
    myBankAccount.init();
    myBankAccount.show();
    myBankAccount.withdraw(100);
    myBankAccount.show();
    myBankAccount.deposit(100);
    myBankAccount.show();
    myBankAccount.withdraw(200);
    myBankAccount.show();
    myBankAccount.withdraw(20);

    BankAccount epargne=myBankAccount;
    epargne.show();
    myBankAccount.show();
}
