#include "point.h"
#include <iostream>
using namespace std;

// initilalizing of the static variable
int Point::counter=0;

Point::Point(double _x, double _y, string _name): x(_x), y(_y), name(_name)
{
    counter++;
    cout << '[' << "Cstd:" << counter << ']';
}

Point::Point(const Point &other)
{
    x = other.x;
    y = other.y;
    name = other.name;

    counter++;
    cout << '[' << "Ccop:" << counter << ']';
}


Point & Point::operator = (const Point & other)
{
    if (this != &other)
    {
        x = other.x;
        y = other.y;
        name = other.name;
    }
    return *this;
}

Point::~Point()
{
    cout << '[' << "Dstr:" << counter << ']';
    counter--;
}

void Point::show() const
{
    cout << endl << name << " : (" << x << ", " << y << ')';
}

void Point::translate(double _x, double _y)
{
    x+=_x;
    y+=_y;
}

void Point::translate(const Point &other)
{
    // call other translate signature
    this->translate(other.x, other.y);
}

std::ostream& operator<<(std::ostream & os, const Point & src)
{
    os << endl << src.name << " : (" << src.x << ", " << src.y << ')';
    return os;
}
