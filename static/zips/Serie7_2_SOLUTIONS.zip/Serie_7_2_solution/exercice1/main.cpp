/**
*   Test code for class template Vector
*
* @author HE-ARC, MSA
* @version 1.0
* @date 04.2021
*
*/
using namespace std;

#include "vector.h"
#include "point.h"

int main()
{
    Vector <int, 4> vi = {0};  
    vi[3] = 5;
    vi[2] = 2;
    cout << vi;

    Vector<double> vd; // 3 elements by default
    vd[0] = 0.0;
    vd[1] = 0.1;
    vd[2] = 0.2;
    cout << vd;
    cout << "\nvd[-8] --> out of range: " << vd[-8] << endl; // first element is modified
    cout << "\nvd[12] --> out of range: " << vd[12] << endl; // last element is modified
    cout << "vd[12] = 99.99" << endl;
    vd[12] = 99.99 ;// vd[12] doesn't exist, --> last element is modified
    cout << "vd[2]: " << vd[2] << endl;
    Vector<double> vd3;
    cout << vd;
    vd3 = vd;
    cout << vd3;

    Vector<Point,2> vpt = {Point (0.0, 0.0, "default")};
    Vector<Point,2> vpt2 = {Point (1.0, 2.0, "other")};
    cout << vpt;
    vpt = vpt2;
    cout << vpt;
    Vector vpt3 (vpt2); // C++17 no need anymore to specify the type if it can be deduce fro the R-Value
    cout << vpt3;

    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
