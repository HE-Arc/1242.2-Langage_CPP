/**
*   Vector is a class template which allows managing any type of component.
*
*   The class offers: setters, getters, constructors and a show method
*   The class must ensure that the Time object is always coherent by
*   implementing some logic in the setters and the constructors
*
* @author HE-ARC, MSA
* @version 1.0
* @date 04.2021
*
*/

#pragma once

#include <iostream>
#include <algorithm> // for copy () C++11
#include <iterator> // for begin () / end () C++11
#include <utility> // for clamp () C++20

using namespace std;

// Class template declaration
// --------------------------
template <typename T, int dim = 3>
class Vector
{
    T data[dim];  //<! adress of dynamically allocated memory
public :
    Vector () = default;
    Vector (const T & initElem);
    Vector (const Vector & src);
    virtual ~Vector () = default;
    T& operator [] (int index);
    Vector & operator = (const Vector & src);
    Vector & operator = (const T & src);

    // Inline to avoid a too open friendship, interesting link below
    // https://web.mst.edu/~nmjxv3/articles/templates.html
    friend std::ostream& operator<<(std::ostream & os, const Vector & src)
    {
      using namespace std;
      os << "(";
      for (const auto & comp : src.data) os << " " << comp;
      os << " )";
      return os; 
    }
} ;

// Class template methods definitions
// ----------------------------------
/**
* @brief Standard constructor to enable uniformize init
* @param initElem The src element to init all vector component
*/
template <typename T, int dim>
Vector<T, dim>::Vector (const T & initElem)
{
  for (auto & comp : data) comp = initElem;
}

/**
* @brief Copy constructor
* @param src The vector src to use for initializing the object
*/
template <typename T, int dim>
Vector<T, dim>::Vector (const Vector & src)
{
  // C++11
  std::copy (begin (src.data), end (src.data), begin (data));
}

/**
* @brief operator [] implementation
*
* @param index The new hour value of the Time object. Must be in the range [0;23]
* @return int minute: The new minute value of the Time object. Must be in the range [0;59]
*/
template <typename T, int dim>
T & Vector<T, dim>::operator [] (int index)
{
  // Old-style implementation 
  /*if (index < 0) 
  {
    index = 0;
  }
  else if (index >= static_cast<int>(sizeof(data)/ sizeof(T)-1)) 
  {
    index = static_cast<int>(sizeof(data)/ sizeof(T)-1);
  }
  return data [index];*/
  // C++20 (clamp)
  return data[std::clamp (index, 0, static_cast<int>(sizeof(data)/ sizeof(T)-1))];
}

/**
* @brief operator = standard implementation 
*
* @param src The src vector to use
* @return The initialized vector by reference
*/
template <typename T, int dim>
Vector<T, dim> & Vector<T, dim>::operator = (const Vector & src)
{
  if(this != &src) std::copy (begin (src.data), end (src.data), begin (data));
  return *this;
}

/**
* @brief operator = special implementation to fill all vector component with one type object value
*
* @param src The value type object to use to fill out all vector components
* @return The initialized vector by reference
*/
template <typename T, int dim>
Vector<T, dim> & Vector<T, dim>::operator = (const T & src)
{
  for (auto & comp : data) comp = src;
  return *this;
}