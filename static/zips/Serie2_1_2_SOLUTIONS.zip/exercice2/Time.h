/**
*   TIME is a class to represent a time with hours (0-23) and minutes(0-59)
*
*   The class offers: setters, getters, constructors and a show method
*   The class must ensure that the Time object is always coherent by
*   implementing some logic in the setters and the constructors
*
* @author HE-ARC, OHU
* @version 1.0
* @date 02.2021
*
*/

#ifndef TIME_H
#define TIME_H

#define HOURS_PER_DAY 24    // to avoid magic numbers
#define MINUTES_PER_HOUR 60 // to avoid magic numbers

#include <iostream>

class Time
{
public:
    // Constructeur par défaut
    Time() : hour(12), minute(0)
    {
        std::cout << "  -> Appel du constructeur par defaut" << std::endl;
    }

    // Constructeur standard
    Time(int h, int m);

    // Constructeur de conversion
    Time(double realTime); // déclaration, la définition est dans le .cpp

    // Accesseurs inline
    int getHour() { return hour; }
    int getMinute() { return minute; }

    // Modificateurs (pas inline car contiennent du code logique)
    void setHour(int);
    void setMinute(int);

    void show();

private:
    short hour;
    short minute;
};

#endif
