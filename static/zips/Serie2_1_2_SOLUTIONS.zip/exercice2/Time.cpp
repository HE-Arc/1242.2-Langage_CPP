#include "Time.h"

/**
* Time(int, int)
* Standard constructor
*
* @param int hour: The new hour value of the Time object. Must be in the range [0;23]
* @param int minute: The new minute value of the Time object. Must be in the range [0;59]
*/
Time::Time(int hour, int minute)
{
    if (hour > 0)
        setHour(hour % HOURS_PER_DAY);
    else
        this->hour = 0; // l'utilisation de this est nécessaire ici car paramètre homonyme
    if (minute > 0)
    {
        setMinute(minute % MINUTES_PER_HOUR);
        this->hour += minute / MINUTES_PER_HOUR;
        setHour(this->hour); // to check an overflow
    }
    else
        this->minute = 0;

    std::cout << "  -> Appel du constructeur standard" << std::endl;
}

/**
* Time(int)
* Conversion constructor
*
* @param double realTime: A time value in decimal format (e.g 16H40 specified as 16.666667)
*/
Time::Time(double realTime)
{
    if (realTime < HOURS_PER_DAY)
    {
        this->setHour((int)realTime);
        setMinute(60 * (realTime - (int)realTime));
    }
    this->setHour((int)realTime);
    std::cout << "  -> Appel du constructeur de conversion" << std::endl;
}

/**
* setHour(int h)
* Modifier setting a new value to the hour member of the Time object
*
* @param int h: The new hour value of the Time object. Must be in the range [0;23]
*/
void Time::setHour(int h)
{
    if (h >= 0)
        this->hour = h % HOURS_PER_DAY;
}

/**
* setMinute(int m)
* Modifier setting a new value to the minute member of the Time object
*
* @param int m: The new minute value of the Time object. Must be in the range [0;59]
*/
void Time::setMinute(int m)
{
    if (m >= 0)
    {
        this->minute = m % MINUTES_PER_HOUR;

        this->hour += m / MINUTES_PER_HOUR;
        setHour(this->hour);
    }
    else
        this->minute = 0;
}

/**
*   show()
*
*   Displays the Time object in the console with "HH:MM" format.
*
*/
void Time::show()
{
    // On affiche un zero si une valeur est inférieure a 10
    std::cout << (this->getHour() > 9 ? "" : "0") << this->hour << 'H'
              << (this->minute > 9 ? "" : "0") << this->minute << std::endl
              << std::endl;
}
