#include "Hero.h"

#include <iostream>

// using namespace He_Arc::RPG; // alternative
namespace He_Arc::RPG
{
    // Hero::Hero(const Hero &) {}; // nothing to do, not really needed

    Hero::Hero(int _strength, int _agility, int _intelligence, double _hp, std::string _name) : strength(_strength), agility(_agility), intelligence(_intelligence), hp(_hp), name(_name) {}

    Hero::~Hero()
    {
    }

    void Hero::show() const
    {
        std::cout << "=================" << std::endl;
        std::cout << "HERO: " << name << std::endl;
        std::cout << "=================" << std::endl;
        std::cout << "strength: " << strength << std::endl;
        std::cout << "agility: " << agility << std::endl;
        std::cout << "intelligence: " << intelligence << std::endl;
        std::cout << "HP: " << hp << std::endl;
    }

    void Hero::interact(const Hero &otherHero)
    {
        std::cout << "Hello valiant " << otherHero.getName() << "! I'm " << this->name << std::endl;
    }

} // namespace He_Arc::RPG