#include "Sword.h"

namespace He_Arc::RPG
{

    std::string Sword::getName() const
    {
        return "Sword";
    }

    int Sword::getPower() const
    {
        return damage;
    }
} // namespace He_Arc::RPG