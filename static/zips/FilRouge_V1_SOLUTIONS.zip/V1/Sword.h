#pragma once

#include <string>

namespace He_Arc::RPG
{

    class Sword
    {
    public:
        Sword() = default;
        Sword(int _damage) : damage(_damage){};
        virtual ~Sword() = default;

        std::string getName() const;
        int getPower() const;

    protected:
    private:
        int damage = 10;
    };
} // namespace He_Arc::RPG