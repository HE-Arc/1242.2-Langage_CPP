#include <iostream>

#include "Hero.h"
#include "Sword.h"


using namespace std;
using namespace He_Arc::RPG;

int main()
{
    Hero aragorn = Hero(20, 20, 20, 20, "Aragorn");

    // equivalent form
    Hero gimli = {10, 5, 1, 20, "Gimli"};       // c++11
    Hero gandalf = {2, 2, 10, 10, "Gandalf"};
    Hero sauron = {20, 20, 10, 999.9, "Sauron"};

    gimli.show();
    cout << endl;
    gandalf.show();
    cout << endl;

    gandalf.interact(aragorn);


    return 0;
}
