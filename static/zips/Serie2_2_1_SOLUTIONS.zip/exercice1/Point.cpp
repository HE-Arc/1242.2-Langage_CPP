#include "point.h"
#include <iostream>
using namespace std;

// initialisation de la variable count
int Point::counter = 0;

Point::Point(char c, double _x, double _y) : x(_x), y(_y), label(c)
{
    cout << "[Default constructor]" << endl;
    counter++;
}

Point::Point(const Point &other)
{
    x = other.x;
    y = other.y;
    label = other.label;

    cout << "[copy constructor]" << endl;
    counter++;
}

void Point::show() const
{
    cout << endl
         << label << " : (" << x << ',' << y << ')';
}

void Point::translate(double _x, double _y)
{
    x += _x;
    y += _y;
}
