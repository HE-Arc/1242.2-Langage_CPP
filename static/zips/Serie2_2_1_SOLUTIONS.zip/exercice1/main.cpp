/**
 *  Serie 02-2 : Premières classes

    Exercice 1 : POINT+

    Buts:
            - Savoir déclarer et initialiser une variable de classe statique privée
            - Savoir rendre accessible (en lecture) la variable par un accesseur statique
            - Comprendre quand un objet est détruit (portée  locale ou dynamique)
            - Comprendre quand un objet est créé
*/

#include <iostream>
#include "Point.h"

using namespace std;

int main()
{
    Point *ptrPoint = nullptr;
    {
        Point p1('A'); 
        Point p2('B', 3, 4);
        cout << "Nombre de points (2): " << Point::getCounter() << endl; // doit afficher 2

        ptrPoint = new Point('D', 10, -5);                               // ALLOCATION DYNAMIQUE avec new
        cout << "Nombre de points (3): " << Point::getCounter() << endl; // doit afficher 3
    }                                                                    // les variables locales au bloc { }, p1 et p2 sont détruites ici

    cout << "Nombre de points (1): " << Point::getCounter() << endl; // doit afficher 1

    delete ptrPoint; // destruction du point alloué dynamiquement
    ptrPoint = nullptr;
    cout << "Nombre de points (0): " << Point::getCounter() << endl; // doit afficher 0

    cout << "\n\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
