#ifndef RECTANGLEASSOC_H
#define RECTANGLEASSOC_H

#include "point.h"

class RectangleAssoc
{
public:
    RectangleAssoc(Point *, Point *);
    RectangleAssoc(const RectangleAssoc &other); // copy constructor

    ~RectangleAssoc();

    double getPerimeter(void) const;
    void show(void) const;
    void translate(double, double);

private:
    Point *cornerUL;
    Point *cornerBR;
};

#endif // RECTANGLEASSOC_H
