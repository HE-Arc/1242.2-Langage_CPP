#include "RectangleAssoc.h"
#include <iostream>

using namespace std;

RectangleAssoc::RectangleAssoc(Point *ptrUL, Point *ptrBR) : cornerUL(new Point(*ptrUL)), cornerBR(new Point(*ptrBR))
{
}

// Le constructeur par recopie du compilateur ne crée PAS de nouveau point.
RectangleAssoc::RectangleAssoc(const RectangleAssoc &other) : cornerUL(new Point(*other.cornerUL)), cornerBR(new Point(*other.cornerBR))
{
}

RectangleAssoc::~RectangleAssoc()
{
    cout << "Destroying a rectangle" << endl;
    delete cornerBR;
    delete cornerUL;
}

void RectangleAssoc::show(void) const
{
    cout << '[';
    cornerUL->show();
    cout << '-';
    cornerBR->show();
    cout << endl
         << ']' << endl;
}

double RectangleAssoc::getPerimeter(void) const
{
    return 2 * (cornerBR->x - cornerUL->x + cornerBR->y - cornerUL->y);
}

void RectangleAssoc::translate(double dx, double dy)
{
    cornerBR->x += dx;
    cornerUL->x += dx;
    cornerBR->y += dy;
    cornerUL->y += dy;
}
