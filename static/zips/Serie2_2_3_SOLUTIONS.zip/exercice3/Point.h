#ifndef POINT_H
#define POINT_H

//class RectangleAssoc;  // forward declaration

class Point
{
public:
  // Constructeur par défaut et standard (paramètres optionnels)
  Point(char, double = 0, double = 0);

  // Constructeur par recopie
  Point(const Point &);

  // destructeur (juste pour décrémenter le compteur static)
  ~Point() { counter--; }

  void show() const;
  void translate(double, double);

  static int getCounter() { return counter; } // donne accès à la variable static counter

private:
  double x, y;
  char label;

  static int counter; // variable membre (de la classe) commune à tous les objets

  friend class RectangleAssoc;
};

#endif
