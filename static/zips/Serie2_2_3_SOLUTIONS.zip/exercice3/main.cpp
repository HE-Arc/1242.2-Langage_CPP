/**
 *  Serie 02-2 : Premières classes

    Exercice 3 : classe RectangleAssoc

    Buts:
            - Relation d'association (partage d'un point par plusieurs rectangles)
            - Comprendre la notion de copie en surface vs copie en profondeur
            - Implémenter un constructeur par recopie non trivial
            - Gestion de la mémoire (allocation dynamique et libération par destructeur)
*/

#include <iostream>
#include "Point.h"
#include "RectangleAssoc.h"

using namespace std;

int main()
{
    Point pt1('A', 5, 5), pt2('B', 10, 12);

    // partie 1
    RectangleAssoc R(&pt1, &pt2);
    R.show(); // OK
    pt1.translate(3, 5);
    R.show(); // ?!? grmph

    // partie 2
    RectangleAssoc copyR(R);
    R.translate(-5, -5);
    R.show();     // OK  expected  [ {0;0}-{5;7} ]
    copyR.show(); // ?!? grmph  expected  [ {5;5}-{10;12} ]  --> OK après complétion de l'exercice

    cout << "\n\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
