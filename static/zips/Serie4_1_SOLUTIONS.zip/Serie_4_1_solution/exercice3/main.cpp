#include <iostream>

using namespace std;

class Point
{
protected:
    double x = 0., y = 0;

public:
    Point(double abs = 0, double ord = 0)
    {
        x = abs;
        y = ord;
    }

    void show()
    {
        identify();
        cout << "   my coordinates are : " << x << ", " << y;
    }
    virtual void identify()
    {
        cout << "I'm a point. \n";
    }
};

class Pixel : public Point
{
    short color = 0;

public:
    Pixel(double _x = 0., double _y = 0., short cl = 1) : Point(_x, _y)
    {
        color = cl;
    }

    virtual void identify() override
    {
        cout << "I'm a pixel of color: \n"
             << color << "\n";
    }
};

int main()
{
    Point p(3, 4);
    Pixel pc(5, 9, 5);

    // Call Point::show() and Point::identify()
    p.show(); // I'm a point...
    // Call Point::show() AND Pixel::identify() 
    pc.show(); // I'm a Pixel...

    cout << "---------------\n" ;
    Point * adp  = &p ;
    Pixel * adpc = &pc ;

    // Call Point::show() and Point::identify()
    adp->show(); // I'm a point...

    // Call Point::show() AND Pixel::identify() 
    adpc->show(); // I'm a Pixel...
    cout << "---------------\n" ;

    adp = adpc;

    // Call Point::show() AND Pixel::identify() 
    adp->show(); // I'm a Pixel...
    // Call Point::show() AND Pixel::identify() 
    adpc->show(); // I'm a Pixel...

    cout << "\nPress any key to continue... ";
    cin.get();
    return 0;
}