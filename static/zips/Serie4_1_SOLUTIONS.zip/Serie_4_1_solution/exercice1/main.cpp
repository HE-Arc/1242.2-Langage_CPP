#include <iostream>
#include "pixel.h"
using namespace std;

int main()
{
    Pixel p1, p2(3.2, 5.5, 0, 0, 0);
    cout << endl;
    p1.show(); // Pixel : (0,0) /n Color (RGB): (0,0,0)

    cout << endl;
    p2.show(); // Pixel : (0,0) /n Color (RGB): (0,0,0)

    cout << endl;
    p2.setColor(255, 0, 128);

    p2.show(); // Pixel : (3.2,5.5) /n Color (RGB): (255,0,128)

    cout << "\n\nPlease hit enter to continue... ";
    cin.get();
    return 0;
}
