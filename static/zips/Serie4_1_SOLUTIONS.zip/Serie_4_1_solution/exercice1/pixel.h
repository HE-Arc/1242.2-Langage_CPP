/**
    * @brief Serie 4.1, exericse 1
    *
    * @author HE-ARC, MSA, 2021
    * @version 1.0
  */
#pragma

#include "point.h"

/**
 * @brief Class Pixel providing color management
*/
class Pixel : public Point
{
public:
    /**
 * @brief Parametrized constructor
 * 
*/
    Pixel(double _x = 0., double _y = 0., int _red = 0, int _green = 0, int _blue = 0, std::string _name = "Pixel");
    // Optional
    //Pixel(double _x = 0, double _y = 0, int _c = 0, std::string _name = "Pixel");

    /**
 * @brief Destructor
*/
    ~Pixel();
    /**
 * @return Red color part
*/
    int getR() const;
    /**
 * @return Green color part
*/
    int getG() const;
    /**
 * @return Blue color part
*/
    int getB() const;

    /**
 * @brief Set R G B color
 * @param red Red color part
 * @param green Green color part
 * @param blue Blue color part
*/
    void setColor(int red, int green, int blue);
    /**
 * @brief Display a pixel with position and color
*/
    void show() const;

private:
    //int color = 0; /**< Option, one int encoding
    int red = 0;   /**< Red component  */
    int green = 0; /**< Green component */
    int blue = 0;  /**< Bliue component */
};
