#include <iostream>
#include "pixel.h"

//Pixel::Pixel(double _x, double _y, int _c, std::string _name, int _c) : Point(_x, _y, _name), color(_c) {}
Pixel::Pixel(double _x, double _y, int _r, int _g, int _b, std::string _name) : Point(_x, _y, _name), red(_r), green(_g), blue(_b)
{
}

Pixel::~Pixel()
{
}

int Pixel::getR() const
{
    return red;
    /// Optional
    //return (color & 0x00FF0000) >> 16;
    //return (color >> (8*2)) & 0xff;
    //return (color & 0x00FF0000) / 0x10000;
}

int Pixel::getG() const
{
    return green;
    // Optional
    //return (color & 0x00FF0000) >> 16;
    //return (color >> (8*2)) & 0xff;
    //return (color & 0x00FF0000) / 0x10000;
}

int Pixel::getB() const
{
    return blue;
    // Optional
    // return (color & 0x00FF0000) >> 16;
    // return (color >> (8*2)) & 0xff;
    // return (color & 0x00FF0000) / 0x10000;
}

void Pixel::setColor(int red, int green, int blue)
{
    if (
        red >= 0 && red < 256 &&
        green >= 0 && green < 256 &&
        blue >= 0 && blue < 256)
    {
        this->red = red;
        this->green = green;
        this->blue = blue;
        // Optional
        // color = (r << 16) + (g << 8) + (b);
        // color = r * 0x10000 + g*0x100 + b;
    }
    else
    {
        // No change if a color is invalid
        std::cout << "Color values are not valid" << std::endl;
    }
}

void Pixel::show() const
{
    Point::show();

    std::cout << std::endl
              << "Color (RGB): ("
              << getR() << ", " << getG() << ", "
              << getB() << ")" << std::endl;

    // Optional
    // std::cout << " #" << hex << color << dec << std::endl;
}
