
#include <iostream>

using namespace std;

class Point
{
protected:            
    double x = 0.,y = 0.;
public :
    Point (double abs=0, double ord=0) { x=abs ; y=ord ; }

    virtual void show ()
    {
        cout << "I'm a point. \n" ;
        cout << " my coordinates are : " << x << " " << y << "\n" ;
    }
};

class Pixel : public Point
{ 
	short color = 0;
public :
	Pixel (double _x=0., double _y=0., short cl=1) : Point (_x, _y)
	{ color = cl ; }

	virtual void show () override
	{
		cout << "I'm a pixel. \n" ;
		cout << "   my coordinates are : " << x << ", " << y ;
 		cout << "   and my color is :    " << color << "\n" ;
	}
};   

int main()
{
	Point p(3., 5.); 
	Point * adp = &p;
	Pixel pc(8., 6., 2);
	Pixel * adpc = &pc;

	// call Point::show()
	adp->show(); // I'm a point. My coordinates are 3, 5

	// call Pixel::show()
	adpc->show(); // I'm a pixel. My coordinates are 8, 6 and my color is 2.
	cout << "------------------" << endl;
	// adp points now on a pixel object
	adp = adpc;
	// call Pixel::show() as show is virtual 
	adp->show(); // I'm a pixel. My coordinates are 8, 6 and my color is 2.
	// call Pixel::show() as show is virtual 
	adpc->show(); // I'm a pixel. My coordinates are 8, 6 and my color is 2.
	return 0;
}