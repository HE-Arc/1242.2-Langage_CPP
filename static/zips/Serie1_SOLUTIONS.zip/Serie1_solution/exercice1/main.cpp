/**
 *  Serie 01 : de C à C++

    Exercice 1 : formattage de l'affichage avec cout

*/
#include <iostream>
#include <iomanip>

void exercise1();

int main()
{
    exercise1();
    return 0;
}

void exercise1()
{
    bool isNumber = true;
    std::cout << std::boolalpha << isNumber << " " << !isNumber << std::endl;
    std::cout << std::noboolalpha << isNumber << " " << !isNumber << std::endl;
    std::cout << std::endl;

    int x = 15;
    std::cout << "hexadecimal: " << std::hex << x << " decimal: " << std::dec << x << " octal: " << std::oct << x << std::endl;
    std::cout << std::dec << x << " " << x << " " << x << std::endl;
    std::cout << std::endl;

    double dbl = -5345.123456789;
    std::cout << dbl << std::endl;
    std::cout << std::setprecision(8) << std::fixed << dbl << std::endl;
    std::cout << std::setprecision(4) << std::scientific << dbl << std::endl;
    std::cout << std::setprecision(6) << std::defaultfloat << dbl << std::endl;
    std::cout << std::endl;
    return;
}
