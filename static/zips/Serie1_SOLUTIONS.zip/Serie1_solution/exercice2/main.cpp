/**
 *  Serie 01 : de C à C++

    Exercice 2 : surcharge de fonctions

*/

#include <iostream>
using namespace std;

double minimum(double val1, double val2)
{
  cout << "reels : ";
  return val1 < val2 ? val1 : val2;
}

int minimum(int val1, int val2)
{
  cout << "entiers : ";
  return val1 < val2 ? val1 : val2;
}

int main()
{
  cout << minimum(7, 3) << endl;
  cout << fixed << minimum(7., 3.) << endl;

  /**Les appels suivants sont refusés par le compilateur car ils ne correspondent
 * à aucune des 2 signatures. Par contre si on supprime la fonction qui reçoit
 * deux entiers, les deux appels ci-dessous fonctionnent.*/
  //cout << minimum(7.0, 3) << endl;
  //cout << minimum(7, 3.0f) << endl;
  cout << "Please hit ENTER to continue... ";
  cin.clear();
  cin.get();
  return 0;
}
