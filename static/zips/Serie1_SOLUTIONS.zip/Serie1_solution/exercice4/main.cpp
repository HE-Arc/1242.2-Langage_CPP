/**
 * Ecrire un programme qui:
 * utilise une fonction `askForAString()` demandant à l'utilisateur de saisir une phrase 
 * et renvoyant cette phrase au programme principal sous la forme d'un pointeur char*. Le programme déclarera ensuite  une variable de type `string` pour y copier cette phrase et en calculer sa longueur avec la fonction `size()`. Une fois la copie faite, libérer la mémoire allouée dynamiquement et afficher le message contenu dans le *string*. 
 * 
 * Bonus : Concaténer au string des points ('.') jusqu'à concurrence de sa capacité.
 *
 * Consigne : gérer l'allocation dynamique et la récupération de la mémoire avec les opérateurs C++ `new`et `delete`.*
 *
 * @author HE-ARC, OHU, 2021
 * @version 1.0
*/

#include <iostream>
#include <string>
#include <cstdio> // pour utiliser fgets

using namespace std;

#define MAX_LENGTH 256

char *askForAString();

int main()
{
    char *ptrInput = nullptr;
    ptrInput = askForAString();
    cout << ptrInput;
    string inputString = ptrInput;
    delete[] ptrInput; // sans [], seule la mémoire du premier char serait récup

    // BONUS        
    cout << "\nLength: " << inputString.size() << "\t\tCapacity: " << inputString.capacity() << endl;
    int spaceAvailable = inputString.capacity() - inputString.size();
    inputString.append(spaceAvailable, '.');
    cout << endl
         << inputString << endl;

    system("PAUSE");
    return 0;
}

char *askForAString()
{
    char *sentence = new char[MAX_LENGTH];
    cout << "Please type a sentence with a few words: ";
    //cin >> sentence;        // ne récupère que le premier mot
    //scanf("%s",sentence);   // ne récupère que le premier mot
    fgets(sentence, MAX_LENGTH - 1, stdin);
    return sentence;
}

