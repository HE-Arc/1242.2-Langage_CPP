/**
 *  Serie 01 : de C à C++

    Exercice 3 : passage de paramètres

*/

#include <iostream>
using namespace std;

int divide(int dividend, int divisor, int &remainder);
int divide(int dividend, int divisor, int *pRemainder);
bool divide(int dividend, int divisor, int &remainder, int &quotien);

int main()
{
    int remainder;
    cout << "** Division de 37 par 2 **\n"
         << endl;

    int quotient = divide(37, 2, remainder); // appel de divide(int, int, int& )
    cout << "= Passage par référence =" << endl;
    cout << "quotient : " << quotient << ", reste : " << remainder << endl
         << endl;

    quotient = divide(37, 2, &remainder); // appel de divide(int, int, int* )
    cout << "= Passage par pointeur =" << endl;
    cout << "quotient : " << quotient << ", reste : " << remainder << endl;


    bool ok = divide(37, 3, remainder, quotient); // bool divide (int, int, int&, int&)
    cout << "= Passages par référence =" << endl;
    cout << "quotient : " << quotient << ", reste : " << remainder << endl
         << endl;

    cout << "Appuyez sur entrée pour continuer... ";
    cin.clear();
    cin.get();
    return 0;
}

/* Une fonction ne peut retourner qu'UN résultat -->
   on utilise des paramètres pour en "renvoyer" plusieurs.
   Deux techniques: par adresse, par référence */
int divide(int dividend, int divisor, int &remainder)
{
    if (divisor == 0)
    {
        if (dividend == 0)
            cout << "Résultat indéfini";
        else
            cout << "Résultat infini";
        exit(0);
    }
    remainder = dividend % divisor;
    return dividend / divisor;
}


int divide(int dividend, int divisor, int *pRemainder)
{
    if (divisor == 0)
    {
        if (dividend == 0)
            cout << "Résultat indéfini";
        else
            cout << "Résultat infini";
        exit(0);
    }
    *pRemainder = dividend % divisor;
    return dividend / divisor;
}

/* A version with both quotient and remainder returned back as parameters*/
bool divide(int dividend, int divisor, int &remainder, int &quotien)
{
    if (divisor == 0)
    {
        if (dividend == 0)
            cout << "Résultat indéfini";
        else
            cout << "Résultat infini";
        return false;
    }
    remainder = dividend % divisor;
    quotien = dividend / divisor;
    return true;
}