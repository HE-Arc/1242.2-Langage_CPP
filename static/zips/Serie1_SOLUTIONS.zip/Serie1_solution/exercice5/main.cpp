/**
 *  Serie 01 : de C à C++

    Exercice 5 : Utilisation de la boucle for (range-based) C++11

*/
#include <iostream>

using namespace std;
int main()
{
    int primeNumbers[] = {1, 2, 3, 5, 7, 11, 13};
    int copy[7] = {0, 0, 0, 0, 0, 0, 0};
    int sizeArray = sizeof(primeNumbers) / sizeof(int);

    // AFFICHAGE DU TABLEAU
    for (int i = 0; i < sizeArray; i++)
    {
        std::cout << primeNumbers[i] << std::endl;
    }

    // 1. remplacement de la boucle for par une boucle range-based
    for (const int &elem : primeNumbers) // ou for (const auto &elem : primeNumbers) 
    {
        cout << elem << " " << endl;
    }

    // COPIE DU TABLEAU
    // 2. copier les valeurs du tableau primeNumbers dans copie
    int i = 0;
    for (const int &elem : primeNumbers)
    {
        copy[i++] = elem;
    }
    return 0;
}
