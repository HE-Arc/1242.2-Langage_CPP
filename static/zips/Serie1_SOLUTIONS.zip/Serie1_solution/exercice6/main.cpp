/**
 *  Serie 01 : de C à C++

    Exercice 6 : Utilisation d'une structure en c++ avec des méthodes

*/

#include <iostream>
#include <string>

using namespace std; // directive using (ouvre l'espace de nom std)

// Déclaration de la structure Piece
struct Room
{
  // Variables ou données de la structure
  double width;
  double length;
  double height;
  string name;

  // Fonctions de la structures (on dit aussi "méthodes")
  double surfaceFloor(void) { return width * length; }
  double surfaceWalls(void) { return 2 * (width + length) * height; }
  double volume(void) { return width * length * height; }
  void show(void)
  {
    cout << name << "[L:W:H]" << length << ":" << width << ":" << height << endl;
    cout << "Surface des murs:" << surfaceWalls() << endl;
    cout << "Surface au sol:" << surfaceFloor() << endl;
    cout << "Volume:" << volume() << endl;
  }
};

int main()
{
  Room myBedroom, otherRoom = {2.5, 5, 6};
  myBedroom.height = 3.5;
  myBedroom.width = 4.0;
  myBedroom.length = 3.0;
  myBedroom.name = "Chambre a coucher";

  cout << myBedroom.name << "[L:W:H]" << myBedroom.length << ":" << myBedroom.width << ":" << myBedroom.height << endl;
  cout << "Surface des murs:" << myBedroom.surfaceWalls() << endl;
  cout << "Surface au sol:" << myBedroom.surfaceFloor() << endl;
  cout << "Volume:" << myBedroom.volume() << endl;

  Room kitchen = {2.5, 3.5, 2.4, "Cuisine"}; // liste d'initialisation C++11
  kitchen.show();

  return 0;
}
