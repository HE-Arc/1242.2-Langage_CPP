/**
*   Vector is a class to represent a vector of n integer
*
* @author HE-ARC, FRT
* @version 1.0
* @date 04.2021
*
*/
#include "vector.hpp"
#include <iostream>
#include <exception>

Vector::Vector(unsigned int _size, int _value)
{
    try
    {
        size = _size;
        data = new int[size];
        for (int i=0; i < size; i++)
        {
            data[i] = _value;
        }
    }
    catch(const std::bad_alloc& e )
    {
        std::cout << "  catched in Vector(int, int) >>> " << e.what() << std::endl;
        cleanData();
    }
}

Vector::Vector(const Vector &v)
{
    try
    {
        size = v.size;
        data = new int[size];
        for (int i = 0; i < size; i++)
        {
            data[i] = v.data[i];
        }
    }
    catch(const std::bad_alloc& e )
    {
        std::cout << "  catched in Vector(const Vector&) >>> " << e.what() << std::endl;
        cleanData();
    }
}

Vector::~Vector()
{
    cleanData();
};

Vector &Vector::operator=(const Vector &vec)
{
    if (this != &vec)
    {
        cleanData();
        try
        {
            size = vec.size;
            data = new int[size];
            for(int i = 0; i < size; i++)
            {
                data[i] = vec.data[i];
            }
        }
        catch(const std::bad_alloc & e)
        {
            std::cout << "  catched in operator= >>> " << e.what() << std::endl;
            cleanData();
        }
    }
    return *this;
}

int &Vector::operator[](int i)
{
    if (data!=nullptr && i >= 0 && i < size)
    {
        return data[i];
    }
    else
    {
        throw std::out_of_range("  thrown from operator[] :: Out of range");
    }
}

void Vector::cleanData()
{
    if(data != nullptr)
    {
        delete [] data;
    }
    data = nullptr;
    size = 0;
}

std::ostream &operator<<(std::ostream &out, const Vector &v)
{
    out << "[ ";
    for (int i = 0; i < v.size; i++)
    {
        out << v.data[i] << ' ';
    }
    out << "]";
    return out;
}

Vector operator+(const Vector &v1, const Vector &v2)
{
    if (v1.size == v2.size)
    {
        Vector result(v1.size);
        for (int i = 0; i < v1.size; i++)
            result.data[i] = v1.data[i] + v2.data[i];
        return result;
    }
    else
    {
        return v1;
    }
}


