/**
*
*   Exceptions in class "Vector"
*
* @author HE-ARC, FRT
* @version 1.0
* @date 05.2021
*/
#include <iostream>
#include "vector.hpp"
#include <cstdlib> 
#include <vector>
#include <cmath>   // pow
#include <limits>  // INT_MAX

using namespace std;

int main()
{
    const int SIZE = INT_MAX;

    // Allocation test in constructor Vector(int, int)
    cout << "Vector v1("<< SIZE << ");" << endl;   
    Vector v1(SIZE);

    // Allocation test in assignment operator 
    int nbOfTry = 7;
    vector<Vector> tabV(nbOfTry);
    for(int i=0;i<nbOfTry;i++)
    {
        cout << "Allocation of the "<< i+1 << "th vector of " << SIZE << " elements " << endl; 
        tabV[i] = v1;
    }
    
    // Size of allocated memory 
   long long sumInBytes=0;
    for(auto& v : tabV)
    {
        sumInBytes += v.getSizeInBytes();
    }
    cout << "Memory allocated : " << sumInBytes << " Bytes" << endl;
    cout << "Memory allocated : " << sumInBytes/pow(1000,3) << " GB (1000)" << endl;
    cout << "Memory allocated : " << sumInBytes/pow(1024,3) << " GB (1024)" << endl;

    // Allocation test in constructor Vector(int, int)
    cout << "Vector v2("<< SIZE << ");" << endl;   
    Vector v2(SIZE);

    // Allocation test in recopy constructor Vector(Vector &)
    cout << "Vector v3 = v1;" << endl;                
    Vector v3 = v1; 

    // Allocation test in affectation operator operator=
    cout << "Vector v5;" << endl;                    
    Vector v5;
    cout << "v5 = v1;" << endl;                        
    v5 = v1;
 
    // Allocation test in Vector(int, int) with wrong value -> MUST BE CHECKED IN CONSTRUCTOR !!!!
    cout << "Vector v6(-1);" << endl;                 
    Vector v6(-1);

    // Test out of range acces in Vector
    try
    {
        cout << "v1[-1] = 5;" << endl;                        
        v1[-1] = 5;
    }
    catch ( const std::out_of_range & e )
    {
        cout << "  catched in main() >>>> " << e.what() << endl;
    }

    // Test out of range acces in std::vector
    try
    {   
        cout << "tabV.at(-1).getSizeInBytes()" << endl;
        cout << tabV.at(-1).getSizeInBytes() << endl;
    }
    catch(const exception & e)
    {
        cout << "  catched in main()  >>>> " << e.what() << endl;
    }

    return 0;
}
