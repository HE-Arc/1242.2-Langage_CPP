#pragma once
/**
*   Vector is a class to represent a vector of n integer
*
*   The class offers:
*   - constructors, destructor and a show method
*   - assignation, and an element access []
*
* @author HE-ARC, FRT
* @version 1.0
* @date 03.2021
*
*/
#include <iostream>

class Vector
{
public:
    Vector()=default;
    Vector(unsigned int _size, int _value = 0);
    Vector(const Vector &v);
    ~Vector();

    Vector &operator=(const Vector &v);
    friend Vector operator+(const Vector &v1, const Vector &v2);
    int &operator[](int i);
    long long getSizeInBytes() const {
        return (long long)size*sizeof(*data);
    }

    friend std::ostream &operator<<(std::ostream &out, const Vector &v);

private:
    int *data = nullptr;
    int size  = 0;
    void cleanData();
};

