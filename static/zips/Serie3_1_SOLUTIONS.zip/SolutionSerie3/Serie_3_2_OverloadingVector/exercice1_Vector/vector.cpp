#include "vector.h"
#include <iostream>

Vector::Vector()
{
    data=nullptr;
    size = 0;
};

Vector::Vector(int n, int val)
{
    data = new int[n];
    size = n;
    for(int i=0; i<size; i++)
        data[i]=val;
}

Vector::Vector(const Vector& v)
{
    size=v.size;
    data = new int[size];
    for(int i=0; i<size; i++)
        data[i]=v.data[i];
}

Vector::~Vector(){
    if (data!=nullptr)
    {
        delete [] data;
        data= nullptr;
        size=0;
    }
};

Vector& Vector::operator=(const Vector& vec)
{
    if (this!=&vec)
    {
        if (data!=nullptr)
             delete [] data;
        size=vec.size;
        data = new int[size];
        for(int i=0; i<size; i++)
            data[i]=vec.data[i];
    }
    return *this;
}

int& Vector::operator[](int i)
{
    if (i>=0 && i<size)
        return data[i];
    else
        return data[0];
}

std::ostream& operator<<(std::ostream& out, const Vector& v)
{
    out << "[ ";
    for(int i=0; i<v.size; i++)
        out << v.data[i] << ' ';
    out << "]";
    return out;
}

Vector operator+(const Vector& v1, const Vector& v2)
{
    if(v1.size==v2.size)
    {
        Vector result(v1.size);
        for(int i=0; i<v1.size; i++)
            result.data[i]=v1.data[i]+v2.data[i];
        return result;
    }
    else
    {
        return v1;
    }
}

