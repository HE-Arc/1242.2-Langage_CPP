/**
*   1242.3 Programmation C++
*
*   S�rie 3.1 - Exercice 3: Classe Vecteur - Surcharge de opérateurs
*
* @author HE-ARC, FRT
* @version 1.0
* @date 03.2021
*/

#include <iostream>
#include "vector.h"

using namespace std;

int main()
{
    Vector v1;
    Vector v2(3);
    Vector v3= Vector(3,10);

    cout << "v1: " << v1 << " v2: " << v2 << " v3: " << v3 << endl << endl;

    
    cout << "v1: " << v1 << " v3: " << v3 << endl;
    cout << "v1=v3;" << endl;
    v1=v3;
    cout << "v1: " << v1 << " v3: " << v3 << endl<< endl;

    cout << "v1: " << v1 << endl;
    cout << "v1[2]=100;" << endl;
    v1[2]=100;
    cout << "v1: " << v1 << endl<< endl;

    cout << "v1[2] " << v1[2] << endl;
    cout << "v3[2] " << v3[2] << endl << endl;
 
    cout << "v1: " << v1 << endl;
    cout << "v1[1000]=200; " << endl;
    v1[1000]=200;
    cout << "v1: " << v1 << endl << endl;

    Vector v4(5,5);
    cout << "v1: " << v1 << " v3: " << v3 << " v4: " << v4 << endl;
    cout << "v1=v3+v4; " << endl;
    v1=v3+v4;
    cout << "v1: " << v1 << " v3: " << v3 << " v4: " << v4 << endl << endl;

    cout << "v1: " << v1 << " v2: " << v2 << " v3: " << v3 << endl;
    cout << "v1=v3+v3; " << endl;
    v1=v3+v3;
    cout << "v1: " << v1 << " v2: " << v2 << " v3: " << v3 << endl << endl;

    return 0;
}
