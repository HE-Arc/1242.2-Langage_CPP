/**
*   Vector is a class to represent a vector of n integer
*
*   The class offers:
*   - constructors, destructor and a show method
*   - assignation, and an element access []
*
* @author HE-ARC, FRT
* @version 1.0
* @date 03.2021
*
*/#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>


class Vector
{
    public:
        Vector();
        Vector(int n, int val=0);
        Vector(const Vector& v);
        ~Vector();

        Vector& operator=(const Vector& v);
        friend Vector operator+(const Vector& v1, const Vector& v2);
        int&    operator[](int i);

        friend std::ostream& operator<<(std::ostream& out, const Vector& v);

    private:
        int* data=nullptr;
        int  size = 0;
};


#endif // VECTOR_H
