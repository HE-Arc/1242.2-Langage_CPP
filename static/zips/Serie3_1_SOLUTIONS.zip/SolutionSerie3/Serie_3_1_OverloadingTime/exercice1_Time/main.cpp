/**
*   1242.3 Programmation C++
*
*   Série 2.1 - Exercice 2: Classe Time -
*
* @author HE-ARC, OHU
* @version 1.0
* @date 02.2021
*/
#include <iostream>
#include "Time.h"

using namespace std;

int main()
{
     // INSTANTIATION DES OBJETS t1, t2, t3
     //================================================================
     cout << "TEST DES CONSTRUCTEURS :" << endl
          << endl;

     cout << "Time t1; ";
     Time t1;   // Appel du constructeur par défaut
     t1.show(); //-> t1: 12H00

     cout << "Time t2(10,9); ";
     Time t2(10, 9); // Appel du constructeur standard
     t2.show();      //-> t2: 10H09

     cout << "Time t3(17.75); ";
     Time t3(17.75); // Appel du constructeur de conversion
     t3.show();      //-> t3: 17:45

     // TEST DES MODIFICATEURS
     //================================================================
     cout << endl
          << "TEST DES MODIFICATEURS :\n\n";

     cout << "t2.setHour(7); ";
     t2.setHour(7);
     t2.show(); //-> t2: 07:09

     cout << "t2.setMinute(-40); ";
     t2.setMinute(-40); // -40 < 0 --> 0
     t2.show();         //-> t2: 07:00

     cout << "t2.setMinute(86); ";
     t2.setMinute(86); // 86 %60 --> 26  et h+1
     t2.show();        //-> t2: 08:26

     cout <<"operateur <<" << endl;
     cout <<"================================================================" <<endl;
     cout << "cout << \"t1: \" << t1 << \" t2: \" << t2 << \" t3 \" << t3 << endl;" << endl;;
     cout << "t1: " << t1 << " t2: " << t2 << " t3 " << t3 << endl << endl;

     cout <<"operateur =" << endl;
     cout <<"================================================================" <<endl;
     cout << "t1: " << t1 << " t2: " << t2 << endl;
     cout << "t1 =t2" << endl;
     t1=t2;
     cout << "t1: " << t1 << " t2: " << t2 << endl << endl;

     cout <<"operateur + (fonction non membre amie)" << endl;
     cout <<"================================================================" <<endl;
     t1.setMinute(0);
     cout << "t1: " << t1 << " t3: " << t3 << endl;
     cout << "t1 = t1 + t3" << endl;
     t1 = t1 + t3;
     cout << "t1: " << t1 << " t3: " << t3 << endl << endl;

     cout << "t3: " << t3  << endl;
     cout << "t3 = t3 + 4" << endl;
     t3 = t3 + 4;
     cout << "t3: " << t3  << endl << endl;

     cout << "t3: " << t3  << endl;
     cout << "t3 = 4 + t3" << endl;
     t3 = 4 + t3;
     cout << "t3: " << t3  << endl << endl;

     cout <<"operateur - (fonction membre)" <<endl;
     cout <<"================================================================" <<endl;

     cout << "t1: " << t1 << " t3: " << t3 << endl;
     cout << "t1 = t1 - t3" << endl;
     t1 = t1 - t3;
     cout << "t1: " << t1 << " t3: " << t3 << endl << endl;

     cout << "t3: " << t3 << endl;
     cout << "t3 = t3 - 1" << endl;
     t3 = t3 - 1;
     cout << "t3: " << t3 << endl<< endl;

     cout << "t3: " << t3 << endl;
     cout << "t3 = 1 - t3 Ne fonctionne PAS !!! -> non cummutatif" << endl;
     // t3 = 1 - t3; not allowed
     cout << "t3: " << t3 << endl << endl;


    cout <<" == operator overloading" << endl;
    cout <<"================================================================" <<endl;
    std::cout << t1 << " == " << t1 << boolalpha << " : " << (t1==t1) << std::endl;
    std::cout << t1 << " == " << t2 << boolalpha << " : " << (t1==t2) << std::endl;
    // < operator overloading
    std::cout << t1 << " <  " << t1 << boolalpha << " : " << (t1<t1)  << std::endl;
    std::cout << t1 << " <  " << t2 << boolalpha << " : " << (t1<t2)  << std::endl;
    // >= operator overloading
    std::cout << t1 << " >= " << t1 << boolalpha << " : " << (t1>=t1)  << std::endl;
    std::cout << t1 << " >= " << t2 << boolalpha << " : " << (t1>=t2)  << std::endl;
    // != operator overloading
    std::cout << t1 << " != " << t1 << boolalpha << " : " << (t1!=t1)  << std::endl;
    std::cout << t1 << " != " << t2 << boolalpha << " : " << (t1!=t2)  << std::endl << std::endl;


    std::cout << "\n ++ Increment operator \n";
    cout <<"================================================================" <<endl;

    std::cout << "t2: " << t2 << " t3: " << t3 << std::endl;
    std::cout << "t2 = t3++;" << std::endl;
    t2 = t3++;
    std::cout << "t2: " << t2 << " t3: " << t3 << std::endl;
    std::cout << "t2 =  ++t3;" << std::endl;
    t2 =  ++t3;
    std::cout << "t2: " << t2 << " t3: " << t3 << std::endl;


    cout << "Entrez un temps au format hh:mm :";
    cin >> t2;
    std::cout << "t2: " << t2 << std::endl;

     cout << "\n\nPlease hit ENTER to continue... ";
     cin.get();
     return 0;
}
