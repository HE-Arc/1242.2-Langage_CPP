#pragma once

#include <string>
#include <iostream>


namespace He_Arc::RPG
{

    /**
    * Base class for the characters in the RPG
    *
    * @author STC, MSA
    * @version 1.1
    */
    class Hero
    {
    public:
        Hero() = default; // want it !
        // Hero(const Hero &); // nothing to do, not really needed
        Hero(int _strength, int _agility, int _intelligence, double _hp, std::string _name);
        virtual ~Hero();

        /**
         * @brief Display the hero features
         */
        virtual void show() const;

        /**
         * @brief Make 2 heros interact. Currently, just saying hello. This method is abstract.
         *
         * @param Hero otherHero : the other hero. Currently const but it can evolve if the interaction will modify the other hero
         * @return nothing in this first version
         */
        virtual void interact(const Hero &otherHero) = 0;

        /**
         * @brief Get the hero name
         * 
         * @return the hero name
         */
        std::string getName() const
        {
            return name;
        }

        /**
         * @brief Get the hero strength
         * 
         * @return the hero strength
         */
        int getStrength() const { return strength; }

        /**
         * @brief Get the hero agility
         * 
         * @return the hero agility
         */
        int getAgility() const { return agility; }

         /**
         * @brief Get the hero intelligence
         * 
         * @return the hero intelligence
         */
        int getIntelligence() const { return intelligence; }

        /**
         * @brief Get the hero hitpoints (life points)
         * 
         * @return the hero hp
         */
        int getHp() const { return hp; }

    protected:
        int strength = 0;
        int agility = 0;
        int intelligence = 0;
        double hp = 0; // hitpoints
        std::string name = "no name";

    private:
    };

    std::ostream &operator<<(std::ostream &s, const Hero &p);
} // namespace He_Arc::RPG
