#include "Wizard.h"

#include <iostream>

namespace He_Arc::RPG
{

    void Wizard::show() const
    {
        Hero::show();
        std::cout << "Mana: " << mana << std::endl;
    }

    void Wizard::interact(const Hero &otherHero)
    {
        Hero::interact(otherHero);
        std::cout << "Fellow traveler... I'm a bit lost, do you know where the Shire is?" << std::endl;
    }

    void Wizard::castSpell(Hero &otherHero)
    {
        if (mana > 2)
        {
            std::cout << "FIREBALL!! hahaha!" << std::endl;
            mana -= 2;
            // otherHero.attack(10); // not implemented
        }
        else
        {
            std::cout << "Not enough mana!! Run?" << std::endl;
        }
    }
} // namespace He_Arc::RPG