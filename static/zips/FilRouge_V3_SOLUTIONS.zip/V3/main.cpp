#include <iostream>
#include <list>
#include <algorithm>
#include <vector>

#include "Hero.h"
#include "Warrior.h"
#include "Wizard.h"
#include "Necromancer.h"

#include "Sword.h"


using namespace std;
using namespace He_Arc::RPG;

int main()
{
    // Héritage
    Warrior gimli = {10, 5, 1, 20, "Gimli"};
    Wizard gandalf = {2, 2, 10, 10, "Gandalf", 10};
    Necromancer sauron = {20, 20, 10, 999.9, "Sauron", 50};

    gimli.show();
    cout << endl;
    gandalf.show();
    cout << endl;
    sauron.show();
    cout << endl;

    gimli.interact(gandalf);
    cout << endl;
    gandalf.interact(sauron);
    cout << endl;
    sauron.interact(gimli);
    cout << endl;

    sauron.castSpell(gandalf);
    sauron.riseUndeads();

    sauron.show();
    cout << endl;

    return 0;
}
