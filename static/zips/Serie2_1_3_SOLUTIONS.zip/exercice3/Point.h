#ifndef POINT_H
#define POINT_H

class Point
{
public:
  // Constructeur par défaut et standard (paramètres optionnels)
  Point(char, double = 0, double = 0);

  // Constructeur par recopie
  Point(const Point &);

  void show() const;
  void translate(double, double);

private:
  double x, y;
  char label;
};

#endif
