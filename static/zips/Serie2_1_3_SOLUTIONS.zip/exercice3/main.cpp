/**
*   1242.3 Programmation C++
*
*   Série 2.1 - Exercice 3: Classe Point -
*
* @author HE-ARC, OHU
* @version 1.0
* @date 02.2021
*/

#include <iostream>
#include "Point.h"
#include <cmath>

using namespace std;

Point **generatePolygon(int n)
{
    Point **polygonPoints = new Point *[n]; // to store the n points
    for (int pointNb = 0; pointNb < n; pointNb++)
    {
        double angle = ((double)pointNb / n) * 2 * 3.1415926;
        //cout << angle << endl;
        polygonPoints[pointNb] = new Point('A' + pointNb, cos(angle), sin(angle));
    }
    return polygonPoints;
}

int main()
{
    cout.precision(2); // affichage à 2 digit
    cout << fixed;
    // 1.Points statiques (allocation automatique)
    //Point p0;   // cette déclaration n'est pas acceptée (aucun constructeur sans argument)

    cout << "\nPoint p1('B');\n";
    Point p1('B');
    p1.show();

    cout << "\nPoint p2('A', 3, 4);\n";
    Point p2('A', 3, 4);
    p2.show();

    cout << "\np2.translate(-12,7);\n";
    p2.translate(-12, 7);
    p2.show();

    /// 2.Point alloué dynamiquement
    cout << "\n\nALLOCATION DYNAMIQUE\n";
    cout << "====================\n";
    Point *ptrPt3 = new Point('D', 10, -5);
    cout << "\nPoint *ptrPt3 = new Point(10,-5);\n";
    ptrPt3->show();
    //récupération de la mémoire et mise à nullptr du pointeur
    delete ptrPt3;
    ptrPt3 = nullptr;

    /// BONUS: utilisation de generatePolygon
    int N = 4;
    cout << "\nHow many points do you want the polygon to have ?";
    cin >> N;

    if (N > 2)
    {
        Point **polygonPoints = generatePolygon(N);
        cout << "POLYGON " << N << " points:\n";
        for (int i = 0; i < N; i++)
            polygonPoints[i]->show();

        /// free memory and set pointer to nullptr
        for (int i = 0; i < N; i++)
            delete polygonPoints[i]; // delete each object
        delete[] polygonPoints;      // delete the array of pointers;
        polygonPoints = nullptr;     // reset the pointer
    }
    else
        cout << "that is IMPOSSIBLE !";

    cout << "\n\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
