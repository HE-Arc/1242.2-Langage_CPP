/**
    * @brief Serie 4.2, exercise 1
    *
    * @author HE-Arc, MSA, 2021
    * @version 1.0
  */
#pragma once

#include "figure.h"

/**
 * @brief Class managing a simple rectangle
*/
class Rectangle : public Figure
{
public:
    /**
    * @brief Parametrized constructor 
    */
    Rectangle(const Point& _pos, double _height, double _width) :  Figure(_pos), 
                                                                    height(_height), width(_width) {};

    /**
    * @brief Default compilator destructor
    */
    virtual ~Rectangle() override = default; 

     /**
    * @brief Display the rectangle information
    */
    void show() const override;

    /**
     * @brief Self-cloning override method
     * @param Retruns a pointer on allocated deriveted objetc
    */
    Figure* clone() const override;

private:
    double height = 0.0; /**< Height of the rectangle */
    double width = 0.0; /**< Width of the rectangle */
};
