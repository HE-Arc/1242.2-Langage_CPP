/**
    * @brief Serie 4.2, exercise 1
    *
    * @author HE-Arc, MSA, 2021
    * @version 1.0
  */
#pragma once

#include "Figure.h"

/**
 * @brief Class Triangle managing a simple triangle
*/
class Triangle : public Figure
{
public:
     /**
    * @brief Parametrized constructor 
    */
    Triangle(const Point& _pos, Point _pos2, Point _pos3) : Figure(_pos),
                                                     pos2(_pos2),
                                                     pos3(_pos3) {};
    /**
    * @brief Default compilator destructor
    */
    virtual ~Triangle() override = default;

    /**
    * @brief Display the Triangle
    */
    void show() const override;

     /**
    * @brief Translate the Triangle
    */
    void translate(const Point& shift) override;

    /**
     * @brief Self-cloning override method
     * @param Retruns a pointer on allocated deriveted objetc
    */
    Figure* clone() const override;

private:
    Point pos2 = {0.0, 0.0}; /**< Second corner of the triangle */
    Point pos3 = {0.0, 0.0}; /**< Third corner of the triangle */
};
