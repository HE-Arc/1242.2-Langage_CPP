#include "rectangle.h"
#include <iostream>

using namespace std;

void Rectangle::show() const
{
    cout << "\nRectangle: ";
    Figure::show();
    cout << ", l = " << width << ", h = "<< height << endl;
}

Figure* Rectangle::clone() const
{
    return new Rectangle(*this);
}
