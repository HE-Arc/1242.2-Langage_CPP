/**
    * @brief Serie 4.2, exercise 1
    *
    * @author HE-Arc, MSA, 2021
    * @version 1.0
  */

#pragma once

#include "point.h"

/**
 * @brief Abstract class Figure 
*/
class Figure
{
public:
    /**
    * @brief Parametrized constructor 
    */
    Figure(const Point& _pos) : pos(_pos){};

    /**
    * @brief Default compilator destructor
    */
    virtual ~Figure() = default;

    /**
    * @brief Display the Figure
    * @note Pure virtual method that must be implemented in any subclass
    */
    virtual void show() const = 0;

    /**
    * @brief Return the position of the figure
    */
    Point getPos() const {return pos;}

    /**
    * @brief Translate the Figure
    * @note Virtual method that can be overridden. A default behavior is available.
    */
    virtual void translate(const Point& shift);

    /**
     * @brief Self-cloning virtual method
     * @param Retrun a pointer on allocated deriveted objetc
     */
    virtual Figure* clone() const = 0 ;


protected:
    Point pos = {0., 0.}; /**< Position of the Figure */
};
