/**
    * @brief Serie 7.1, exercise 2
    *
    * @author HE-ARC, OHU, MSA, 2021
    * @version 1.0
  */

#include <iostream>
#include "Time.h"
using namespace std;

template <typename T>
T sum (T tab[], int length)
{
    T result; // need a default constructor
    for (int i=0; i< length;i++)
    {
        result = result + tab[i];
    }
    return result ;
}

// testings
int main()
{
    int   intTable[]   = {3, 5, 2, 1};
    float floatTable[] = {2.5, 3.2, 1.8};
    char  charTable[]  = { 'A', '0', 'i', 'o', 'u' };
    Time timeTable[] = { {5, 10},  {3, 22} };

    cout << sum (intTable, 4) << endl; // type deduction !
    cout << sum (floatTable, 3) << endl; // type deduction !
    cout << sum (charTable, 5) << endl; // type deduction !
    cout << sum (timeTable, 2) << endl; // type deduction !

    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
