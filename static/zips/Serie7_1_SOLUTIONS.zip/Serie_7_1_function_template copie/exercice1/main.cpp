/**
    * @brief Serie 7.1, exercise 1
    *
    * @author HE-ARC, OHU, MSA, 2021
    * @version 1.0
  */
 
#include <iostream>
#include "Time.h"

using namespace std;

// Definition of the template function
template <typename T>
void exchange (T& first, T& second) // parameters by REFERENCE
{
    T temp = first; // call copy constructor (default Time one)
    first = second; // call = operator
    second = temp; // call = operator
}


/// test of the exchange function with different types
int main()
{
    int n1 = 3, n2 = 5;
    float f1=1.76, f2=-5.87;
    Time t1 (10,17), t2 (11,12);
    cout << "n1:" << n1 << " n2:" << n2 << endl;
    exchange(n1, n2); cout << "exchange (n1, n2)\n";
    cout << "n1:" << n1 << " n2:" << n2 << endl;

    cout << "f1:" << f1 << " f2:" << f2 << endl;
    exchange(f1, f2);cout << "exchange (f1, f2)\n";
    cout << "f1:" << f1 << " f2:" << f2 << endl;

    cout << "t1:" << t1 << " t2:" << t2 << endl; // call << operator
    exchange(t1, t2);cout << "exchange (t1, t2)\n";
    cout << "t1:" << t1 << " t2:" << t2 << endl; // call << operator

    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
