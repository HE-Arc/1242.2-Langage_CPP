#include "Time.h"
#include <iostream>
#include <iomanip>  // std::setfill, std::setw

/**
* Time(int, int)
* Standard constructor
*
* @param int hour: The new hour value of the Time object. Must be in the range [0;23]
* @param int minute: The new minute value of the Time object. Must be in the range [0;59]
*/
Time::Time(int hour, int minute)
{
    if (hour > 0)
        setHour(hour % HOURS_PER_DAY);
    else
        this->hour = 0; // l'utilisation de this est nécessaire ici car paramètre homonyme
    if (minute > 0)
    {
        setMinute(minute % MINUTES_PER_HOUR);
        this->hour += minute / MINUTES_PER_HOUR;
        setHour(this->hour); // to check an overflow
    }
    else
        this->minute = 0;

    std::cout << "  -> Appel du constructeur standard" << std::endl;
}

/**
* Time (const Time& tm)
* Copy constructor
*
* @param tm: Time object to use for intializing
*/
Time::Time (const Time& tm)
{
    init (tm);
}

/**
* Time(int)
* Conversion constructor
*
* @param double realTime: A time value in decimal format (e.g 16H40 specified as 16.666667)
*/
Time::Time(double realTime)
{
    if (realTime < HOURS_PER_DAY)
    {
        this->setHour((int)realTime);
        setMinute(60 * (realTime - (int)realTime));
    }
    this->setHour((int)realTime);
    std::cout << "  -> Appel du constructeur de conversion" << std::endl;
}

/**
* setHour(int h)
* Modifier setting a new value to the hour member of the Time object
*
* @param int h: The new hour value of the Time object. Must be in the range [0;23]
*/
void Time::setHour(int h)
{
    if (h >= 0)
        this->hour = h % HOURS_PER_DAY;
}

/**
* setMinute(int m)
* Modifier setting a new value to the minute member of the Time object
*
* @param int m: The new minute value of the Time object. Must be in the range [0;59]
*/
void Time::setMinute(int m)
{
    if (m >= 0)
    {
        this->minute = m % MINUTES_PER_HOUR;

        this->hour += m / MINUTES_PER_HOUR;
        setHour(this->hour);
    }
    else
        this->minute = 0;
}

/**
*   show()
*
*   Displays the Time object in the console with "HH:MM" format.
*
*/
void Time::show()
{
    // On affiche un zero si une valeur est inférieure a 10
    std::cout << (this->getHour() > 9 ? "" : "0") << this->hour << 'H'
              << (this->minute > 9 ? "" : "0") << this->minute << std::endl
              << std::endl;
}

/**
*   operator =()
*
*   Assignment operator
*
*/
Time& Time::operator = (const Time& tm)
{
    init (tm);
    return *this;
}


/**
*   operator =()
*
*   Substraction operator, member fonction
*
*/
Time Time::operator - (const Time& tm)
{
    Time result;
    result.setMinute( this->minute - tm.minute );
    result.setHour(   this->hour   - tm.hour );
    return result;
}

/**
*   operator =()
*
*   Addition operator, non member fonction (friend)
*
*/
Time operator + ( const Time& tm1, const Time& tm2)
{
    Time result;
    result.setMinute( tm1.minute + tm2.minute );
    result.setHour( tm1.hour + tm2.hour );
    return result;
}


short Time::eval() const
{
    return hour*60+minute;
}

void Time::init (const Time& tm)
{
    if(this != &tm)
    {
    hour = tm.hour;
    minute = tm. minute;
    }
}

/**
*   operator <<()
*
*   Displays the Time object in the output stream with "HH:MM" format.
*
*/
std::ostream& operator<<(std::ostream& out, const Time& tm)
{
       return out << std::setfill('0') << std::setw(2) << tm.hour  << ':' << std::setw(2) <<tm.minute ;
}



/**
*   operator >>()
*
*   Read time form input stream at "HH:MM" format.
*
*/
std::istream& operator>>(std::istream& in, Time& tm)
{
    char c;
    short hour, minute;

    in >> hour >> c >> minute;
    if (c == ':') {
        tm.setMinute(minute);
        tm.setHour(hour);
        return in;
    }
    std::cerr << "Erreur de lecture. Programme avorté\n";
    exit(-1);
}
