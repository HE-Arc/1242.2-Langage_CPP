#include "circle.h"
#include <iostream>

using namespace std;

void Circle::show() const
{
    cout << "\nCircle: ";
    Figure::show();
    cout << ", radius=" << radius << endl;
}
