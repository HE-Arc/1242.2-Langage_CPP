/**
 *  Serie 05-1 : Run-time type information

    Exercise 1 : type_id
                 Compare if two objects are instantiate from the same classe
                 Compare if the value of their attributes are the same
    Exercise 1 : dynamic cast
                 Cast a base pointer that points on class to a pointer pointing
                 on the derivated class in ordre to call a specific method.
*/
#include <iostream>

#include "circle.h"
#include "rectangle.h"
#include "triangle.h"

using namespace std;

/* Verify if two Shape objects are the same, it means
   1. Verify if their type is the same, then
   2. Verify if their attributes are the same
*/
bool compareShapes(Figure *fig1, Figure *fig2)
{
    bool areSameTypeID, areSamePosition;
    
    cout << endl
         << " -- Comparison of an objet " << typeid(*fig1).name()
         << " with an objet "             << typeid(*fig2).name()
         << endl;

    areSameTypeID = typeid(*fig1) == typeid(*fig2);
    if (!areSameTypeID)
        cout<< "    - typeid are different" << endl;
    else
    {
        cout<< "    - typeid are the same" << endl;

        /* An other solution to compare the positions
        areSamePosition = fig1->getPos().getX() == fig2->getPos().getX() &&
                          fig1->getPos().getY() == fig2->getPos().getY();
        */
        areSamePosition = fig1->getPos() == fig2->getPos(); 
        if(areSamePosition)
            cout<< endl << "    - positions are the same" << endl;
        else
            cout<< endl << "    - positions are different" << endl;
    }
    return areSamePosition && areSameTypeID;
}


int main()
{
// ================== EXECRISE 1 =================================================

    bool areTheSame;
    // Créer quelques objets et les comparer.

    Rectangle r1(Point( 1,  2),  4.0, 10.0);
    Rectangle r2(Point( 1,  2),  4.0, 10.0);
    Rectangle r3(Point(10, 20), 10.0, 20.0);
    Circle    c1(Point(1.1, 5.3), 5.0);

    cout << endl << "### Comparison of r1 and r2" << endl;
    areTheSame = compareShapes(&r1, &r2);
    cout << endl << "    r1 and r2 are the same : " << boolalpha << areTheSame <<endl;

    cout << endl << "### Comparison of r1 and r3" << endl;
    areTheSame = compareShapes(&r1, &r3);
    cout << endl << "     r1 and r3 are the same : "<< boolalpha << areTheSame <<endl;

    cout << endl << "### Comparison of r1 and c1" << endl;
    areTheSame = compareShapes(&r1, &c1);
    cout << endl << "     r1 and c1 are the same : "<< boolalpha << areTheSame <<endl;

// ================== EXECRISE 2 =================================================

   Figure *myShapes[3];

    myShapes[0] = new Circle(Point(1.1, 5.3), 5.0);
    myShapes[1] = new Triangle(Point(2, 2), Point(10, 3), Point(-1, -1));
    myShapes[2] = new Rectangle(Point(4, 2), 4.0, 10.0);

    cout << "------- List of shapes -----------" << endl;
    for (auto shape : myShapes)
    {
        shape->show();
        //shape->getRadius();
    }
    
    cout << "------- List of shapes with radius of circle  ------" << endl;
    for (int i=0;i<3;i++)
    {
        Circle* ptrCircle = dynamic_cast<Circle*> (myShapes[i]);
        myShapes[i]->show();
        if (ptrCircle != nullptr)
        {
            cout << ">>>> The radius is: " << ptrCircle->getRadius() << endl;
        }
    }

    for (auto shape : myShapes)
    {
        delete shape;
        shape=nullptr;
    }



    cout << "\nPlease hit ENTER to continue... ";
    cin.get();
    return 0;
}
