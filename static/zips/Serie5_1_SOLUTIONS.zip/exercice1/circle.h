/**
    * @brief Serie 4.2, exercise 1
    *
    * @author HE-Arc, MSA, 2021
    * @version 1.0
  */
#pragma once

#include "figure.h"

/**
 * @brief Class managing a simple circle
*/
class Circle : public Figure
{
public:
    /**
    * @brief Parametrized constructor 
    */
    Circle(const Point& _pos, double _radius): Figure(_pos), radius(_radius) {};

    /**
    * @brief Default compilator destructor
    */
    virtual ~Circle() override = default;

    /**
    * @brief Get the radius
    */
   double getRadius() const { return radius;}

      /**
    * @brief Display the circle information
    */
    void show() const override;
private:
    double radius = 0.0; /**< Radius of the Circle */
};
