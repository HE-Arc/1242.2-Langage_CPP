#pragma once

#include "IObject.h"

namespace He_Arc::RPG
{

    /**
    * Class implementing a Shield
    *
    * @author MSA
    * @version 1.0
    */
    class Shield : public IObject
    {
    public:
        Shield() = default;
        Shield(int _solidity) : solidity(_solidity){};
        virtual ~Shield() override = default;

        std::string getName() const override;
        int getFeature() const override;

    protected:
    private:
        int solidity = 5;
    };
} // namespace He_Arc::RPG