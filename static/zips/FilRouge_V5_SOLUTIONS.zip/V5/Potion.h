#pragma once

#include "IObject.h"

namespace He_Arc::RPG
{

    class Potion : public IObject
    {
    public:
        Potion() = default;
        Potion(int _power) : power(_power){};
        virtual ~Potion() override = default;

        std::string getName() const override;
        int getFeature() const override;

    private:
        int power = 10;
    };
} // namespace He_Arc::RPG