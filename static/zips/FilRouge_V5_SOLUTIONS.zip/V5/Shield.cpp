#include "Shield.h"

namespace He_Arc::RPG
{

   std::string Shield::getName() const
   {
      return "Shield";
   }

   int Shield::getFeature() const
   {
      return solidity;
   }
} // namespace He_Arc::RPG