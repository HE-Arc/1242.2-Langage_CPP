#pragma once

#include "IObject.h"

namespace He_Arc::RPG
{

    class Sword : public IObject
    {
    public:
        Sword() = default;
        Sword(int _damage) : damage(_damage){};
        virtual ~Sword() override = default;

        std::string getName() const override;
        int getFeature() const override;

    protected:
    private:
        int damage = 10;
    };
} // namespace He_Arc::RPG