#include "Backpack.h"

namespace He_Arc::RPG
{

    void Backpack::pack(IObject *pObject)
    {
        mStack.push(pObject);
    }

    IObject *Backpack::unPack()
    {
        auto pObject = mStack.top();
        mStack.pop();
        return pObject;
    }
    bool Backpack::isNotEmpty() const
    {
        return !mStack.empty();
    }

} // namespace He_Arc::RPG