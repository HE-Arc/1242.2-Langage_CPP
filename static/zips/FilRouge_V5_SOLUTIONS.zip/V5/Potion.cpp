#include "Potion.h"

namespace He_Arc::RPG
{

    std::string Potion::getName() const
    {
        return "Potion";
    }

    int Potion::getFeature() const
    {
        return power;
    }
} // namespace He_Arc::RPG