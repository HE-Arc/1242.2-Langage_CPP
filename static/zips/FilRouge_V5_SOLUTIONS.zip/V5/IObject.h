#pragma once

#include <string>

/**
* Interface for an object in a pack 
*
* @author MSA
* @version 1.0
*/
class IObject
{
public:
    /**
     * @brief Default destructor
     */
    virtual ~IObject() = default;
    /**
     * @brief Get the object name
     * 
     * @return Object name
     */
    virtual std::string getName() const = 0;
    /**
     * @brief Get the main feature of the object
     * @remark Could be the damage, the solidity, the level of magic, etc... 
     * 
     * @return Power value
     */
    virtual int getFeature() const = 0;
};