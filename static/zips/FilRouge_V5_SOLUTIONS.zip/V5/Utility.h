#pragma once

namespace He_Arc::RPG::Utility
{

    /**
     * @brief Delete and release a pointer
     *
     * @param rPtr: reference on the ptr to delete and release
     */
    template <typename T>
    inline void deletePtr(T *&rPtr)
    {
        if (rPtr)
        {
            delete rPtr;
            rPtr = nullptr;
        }
    }

} // namespace He_Arc::RPG::Utility