#pragma once

#include "Hero.h"
#include "Potion.h"

namespace He_Arc::RPG
{
    class Wizard : public Hero
    {
    public:
        Wizard(int _strength = 10, int _agility = 5, int _intelligence = 1, double _hp = 20, std::string _name = "no_name_wizard", int _mana = 10) : Hero(_strength, _agility, _intelligence, _hp, _name, new Potion()), mana(_mana){};
        
        virtual ~Wizard() override = default;
        void show() const override;
        void interact(const Hero &otherHero) override;
        
        /**
         * @brief Cast a spell agaist another hero passed as parameter
         * 
         * @param otherHero the target of the spell
         */
        void castSpell(Hero &otherHero);

    protected:
        int mana = 0;

    private:
    };
} // namespace He_Arc::RPG