#pragma once

#include <stack>
#include <string>

#include "Sword.h"
#include "IObject.h"

namespace He_Arc::RPG
{

    /**
     * Class implementing a Backpack LIFO style using std::stack
     *
     * @author MSA
     * @version 1.0
     */
    class Backpack
    {
    public:
        /**
         * @brief Default Constructor
         */
        Backpack() = default;

        /**
         * @brief Default destructor
         */
        virtual ~Backpack() = default;

        /**
         * @brief Add an object into the backpack
         *
         * @param IObject* pObject: ptr on the object. 
         * All classes representing an object must implement the IObject class
         */
        void pack(IObject *pObject);
        
        /**
         * @brief Add an object into the backpack
         *
         * @return the IObject
         */
        IObject *unPack();
        
        /**
         * @brief Add an object into the backpack
         *
         * @return True if the backpack contains some object, False otherwise
         */
        bool isNotEmpty() const;

    private:
        std::stack<IObject *> mStack; /**The container of objects */
    };
} // namespace He_Arc::RPG