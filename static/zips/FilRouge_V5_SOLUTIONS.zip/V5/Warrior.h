#pragma once

#include "Hero.h"
#include "Sword.h"
namespace He_Arc::RPG
{

    class Warrior : public Hero
    {
    public:
        Warrior(int _strength = 10, int _agility = 5, int _intelligence = 1, double _hp = 20, std::string _name = "no_name_warrior") : 
            Hero(_strength, _agility, _intelligence, _hp, _name, new Sword()){};

        virtual ~Warrior() override = default;

        void interact(const Hero &otherHero) override;

    protected:
    private:
    };
} // namespace He_Arc::RPG